from django.apps import AppConfig


class BarivaraConfig(AppConfig):
    name = 'BariVara'
